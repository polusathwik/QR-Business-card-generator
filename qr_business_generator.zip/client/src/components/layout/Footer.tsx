import Link from "next/link";
import { QrCode, Github, Twitter, Linkedin } from "lucide-react";

export function Footer() {
    return (
        <footer className="border-t border-border/40 bg-muted/30">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
                    {/* Brand */}
                    <div className="md:col-span-1">
                        <Link href="/" className="flex items-center gap-2.5 mb-4">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600">
                                <QrCode className="h-4 w-4 text-white" />
                            </div>
                            <span className="text-lg font-bold tracking-tight">
                                QR<span className="text-violet-600 dark:text-violet-400">Flow</span>
                            </span>
                        </Link>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-6">
                            Create professional QR codes in seconds. Customize, track, and manage all your QR codes in one place.
                        </p>
                        <div className="flex items-center gap-3">
                            <SocialLink href="#" icon={<Twitter className="h-4 w-4" />} />
                            <SocialLink href="#" icon={<Github className="h-4 w-4" />} />
                            <SocialLink href="#" icon={<Linkedin className="h-4 w-4" />} />
                        </div>
                    </div>

                    {/* Links */}
                    <div>
                        <h4 className="text-sm font-semibold mb-4 uppercase tracking-wider text-foreground">Product</h4>
                        <ul className="space-y-3">
                            <FooterLink href="#features" label="Features" />
                            <FooterLink href="#pricing" label="Pricing" />
                            <FooterLink href="/generate" label="QR Generator" />
                            <FooterLink href="#" label="API Docs" />
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-sm font-semibold mb-4 uppercase tracking-wider text-foreground">Company</h4>
                        <ul className="space-y-3">
                            <FooterLink href="#" label="About" />
                            <FooterLink href="#" label="Blog" />
                            <FooterLink href="#" label="Careers" />
                            <FooterLink href="#" label="Contact" />
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-sm font-semibold mb-4 uppercase tracking-wider text-foreground">Legal</h4>
                        <ul className="space-y-3">
                            <FooterLink href="#" label="Privacy Policy" />
                            <FooterLink href="#" label="Terms of Service" />
                            <FooterLink href="#" label="Cookie Policy" />
                        </ul>
                    </div>
                </div>

                <div className="mt-12 pt-8 border-t border-border/40 flex flex-col sm:flex-row justify-between items-center gap-4">
                    <p className="text-sm text-muted-foreground">
                        &copy; {new Date().getFullYear()} QRFlow. All rights reserved.
                    </p>
                    <p className="text-sm text-muted-foreground">
                        Built with ❤️ for professionals
                    </p>
                </div>
            </div>
        </footer>
    );
}

function FooterLink({ href, label }: { href: string; label: string }) {
    return (
        <li>
            <Link
                href={href}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
            >
                {label}
            </Link>
        </li>
    );
}

function SocialLink({ href, icon }: { href: string; icon: React.ReactNode }) {
    return (
        <a
            href={href}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground hover:border-border hover:bg-muted/50 transition-all duration-200"
        >
            {icon}
        </a>
    );
}
