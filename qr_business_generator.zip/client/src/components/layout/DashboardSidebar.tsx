"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
    LayoutDashboard,
    QrCode,
    Settings,
    LogOut,
    ChevronLeft,
    ChevronRight,
    BarChart3,
    CreditCard,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

const sidebarLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/generate", label: "Create QR", icon: QrCode },
    { href: "/analytics", label: "Analytics", icon: BarChart3, badge: "Pro" },
    { href: "/billing", label: "Billing", icon: CreditCard },
    { href: "/settings", label: "Settings", icon: Settings },
];

export function DashboardSidebar() {
    const pathname = usePathname();
    const [collapsed, setCollapsed] = useState(false);

    return (
        <aside
            className={cn(
                "hidden lg:flex flex-col border-r border-sidebar-border bg-sidebar h-screen sticky top-0 transition-all duration-300 ease-in-out",
                collapsed ? "w-[72px]" : "w-64"
            )}
        >
            {/* Logo Area */}
            <div className="flex items-center justify-between h-16 px-4 border-b border-sidebar-border">
                {!collapsed && (
                    <Link href="/" className="flex items-center gap-2.5">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 shadow-sm">
                            <QrCode className="h-4 w-4 text-white" />
                        </div>
                        <span className="text-lg font-bold tracking-tight">
                            QR<span className="text-violet-600 dark:text-violet-400">Flow</span>
                        </span>
                    </Link>
                )}
                {collapsed && (
                    <Link href="/" className="mx-auto">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 shadow-sm">
                            <QrCode className="h-4 w-4 text-white" />
                        </div>
                    </Link>
                )}
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-3 py-4 space-y-1">
                {sidebarLinks.map((link) => {
                    const isActive = pathname === link.href;
                    return (
                        <Link
                            key={link.label}
                            href={link.href}
                            className={cn(
                                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group",
                                isActive
                                    ? "bg-violet-50 text-violet-700 dark:bg-violet-500/10 dark:text-violet-400"
                                    : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"
                            )}
                        >
                            <link.icon
                                className={cn(
                                    "h-5 w-5 flex-shrink-0 transition-colors",
                                    isActive ? "text-violet-600 dark:text-violet-400" : "text-muted-foreground group-hover:text-foreground"
                                )}
                            />
                            {!collapsed && (
                                <>
                                    <span>{link.label}</span>
                                    {link.badge && (
                                        <span className="ml-auto text-[10px] font-bold uppercase tracking-widest bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-2 py-0.5 rounded-full">
                                            {link.badge}
                                        </span>
                                    )}
                                </>
                            )}
                        </Link>
                    );
                })}
            </nav>

            {/* Bottom Section */}
            <div className="px-3 py-4 border-t border-sidebar-border space-y-1">
                <button
                    onClick={() => setCollapsed(!collapsed)}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-sidebar-accent transition-all duration-200 w-full"
                >
                    {collapsed ? (
                        <ChevronRight className="h-5 w-5 flex-shrink-0" />
                    ) : (
                        <>
                            <ChevronLeft className="h-5 w-5 flex-shrink-0" />
                            <span>Collapse</span>
                        </>
                    )}
                </button>
                <button className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all duration-200 w-full">
                    <LogOut className="h-5 w-5 flex-shrink-0" />
                    {!collapsed && <span>Log Out</span>}
                </button>
            </div>
        </aside>
    );
}
