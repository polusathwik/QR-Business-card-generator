"use client";

import { QrCode, Menu, Bell, Search } from "lucide-react";
import Link from "next/link";

export function DashboardHeader() {
    return (
        <header className="sticky top-0 z-40 h-16 border-b border-border/40 bg-background/80 backdrop-blur-xl flex items-center px-6 gap-4">
            {/* Mobile menu toggle */}
            <button className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted transition-colors">
                <Menu className="h-5 w-5" />
            </button>

            {/* Mobile Logo */}
            <Link href="/" className="lg:hidden flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600">
                    <QrCode className="h-3.5 w-3.5 text-white" />
                </div>
                <span className="text-base font-bold">
                    QR<span className="text-violet-600">Flow</span>
                </span>
            </Link>

            {/* Search */}
            <div className="hidden sm:flex items-center flex-1 max-w-md">
                <div className="relative w-full">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <input
                        type="text"
                        placeholder="Search QR codes..."
                        className="w-full h-9 pl-10 pr-4 rounded-lg border border-input bg-muted/30 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-ring transition-all duration-200"
                    />
                </div>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-2 ml-auto">
                <button className="relative inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-violet-600"></span>
                    </span>
                </button>
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center text-white text-sm font-bold cursor-pointer hover:shadow-md hover:shadow-violet-500/20 transition-shadow">
                    Y
                </div>
            </div>
        </header>
    );
}
