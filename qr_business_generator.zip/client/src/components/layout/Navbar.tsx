"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { QrCode, Sparkles, Menu, X } from "lucide-react";
import { useState } from "react";

export function Navbar() {
    const pathname = usePathname();
    const [mobileOpen, setMobileOpen] = useState(false);

    const isAuthPage = pathname === "/login" || pathname === "/register";

    return (
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex h-16 items-center justify-between">
                    {/* Logo */}
                    <Link href="/" className="flex items-center gap-2.5 transition-opacity hover:opacity-80">
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 shadow-sm shadow-violet-500/20">
                            <QrCode className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-xl font-bold tracking-tight">
                            QR<span className="text-violet-600 dark:text-violet-400">Flow</span>
                        </span>
                    </Link>

                    {/* Desktop Center Nav */}
                    {!isAuthPage && (
                        <nav className="hidden md:flex items-center gap-1">
                            {[
                                { href: "#features", label: "Features" },
                                { href: "#pricing", label: "Pricing" },
                                { href: "#faq", label: "FAQ" },
                            ].map((link) => (
                                <Link
                                    key={link.href}
                                    href={link.href}
                                    className="px-4 py-2 text-sm font-medium text-muted-foreground rounded-lg hover:text-foreground hover:bg-muted/50 transition-all duration-200"
                                >
                                    {link.label}
                                </Link>
                            ))}
                        </nav>
                    )}

                    {/* Desktop Right CTA */}
                    <div className="hidden md:flex items-center gap-3">
                        <Link
                            href="/login"
                            className="inline-flex h-9 items-center justify-center rounded-lg px-4 text-sm font-medium transition-all duration-200 hover:bg-muted text-muted-foreground hover:text-foreground"
                        >
                            Log in
                        </Link>
                        <Link
                            href="/register"
                            className="inline-flex h-9 items-center justify-center rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 px-4 text-sm font-medium text-white shadow-md shadow-violet-500/20 transition-all duration-200 hover:shadow-lg hover:shadow-violet-500/30 hover:scale-[1.02] gap-1.5"
                        >
                            <Sparkles className="w-3.5 h-3.5" />
                            Get Started Free
                        </Link>
                    </div>

                    {/* Mobile Menu Toggle */}
                    <button
                        onClick={() => setMobileOpen(!mobileOpen)}
                        className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted transition-colors"
                    >
                        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                    </button>
                </div>

                {/* Mobile Menu */}
                {mobileOpen && (
                    <div className="md:hidden pb-4 pt-2 border-t border-border/40">
                        <nav className="flex flex-col gap-1">
                            {[
                                { href: "#features", label: "Features" },
                                { href: "#pricing", label: "Pricing" },
                                { href: "#faq", label: "FAQ" },
                            ].map((link) => (
                                <Link
                                    key={link.href}
                                    href={link.href}
                                    onClick={() => setMobileOpen(false)}
                                    className="px-4 py-2.5 text-sm font-medium text-muted-foreground rounded-lg hover:text-foreground hover:bg-muted/50 transition-colors"
                                >
                                    {link.label}
                                </Link>
                            ))}
                            <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-border/40">
                                <Link
                                    href="/login"
                                    className="inline-flex h-10 items-center justify-center rounded-lg px-4 text-sm font-medium transition-colors hover:bg-muted"
                                >
                                    Log in
                                </Link>
                                <Link
                                    href="/register"
                                    className="inline-flex h-10 items-center justify-center rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 px-4 text-sm font-medium text-white shadow-md gap-1.5"
                                >
                                    <Sparkles className="w-3.5 h-3.5" />
                                    Get Started Free
                                </Link>
                            </div>
                        </nav>
                    </div>
                )}
            </div>
        </header>
    );
}
