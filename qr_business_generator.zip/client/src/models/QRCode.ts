import mongoose from "mongoose";

const qrCodeSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },
        name: {
            type: String,
            required: [true, "QR code name is required"],
            trim: true,
            maxlength: [100, "Name cannot exceed 100 characters"],
        },
        type: {
            type: String,
            enum: ["url", "text", "vcard", "wifi", "email", "phone"],
            required: [true, "QR code type is required"],
        },
        value: {
            type: String,
            required: [true, "QR code value/content is required"],
        },
        // Customization
        color: {
            type: String,
            default: "#7c3aed",
        },
        bgColor: {
            type: String,
            default: "#ffffff",
        },
        cornerStyle: {
            type: String,
            enum: ["square", "rounded"],
            default: "rounded",
        },
        logo: {
            type: String, // URL to uploaded logo
            default: null,
        },
        // Analytics
        scans: {
            type: Number,
            default: 0,
        },
        isActive: {
            type: Boolean,
            default: true,
        },
    },
    {
        timestamps: true,
    }
);

// Index for faster queries by user
qrCodeSchema.index({ user: 1, createdAt: -1 });

export default mongoose.models.QRCode || mongoose.model("QRCode", qrCodeSchema);
