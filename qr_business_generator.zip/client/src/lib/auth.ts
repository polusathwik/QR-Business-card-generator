import jwt from "jsonwebtoken";
import { NextRequest } from "next/server";
import User from "@/models/User";
import connectDB from "@/lib/db";

export const generateToken = (id: string) => {
    return jwt.sign({ id }, process.env.JWT_SECRET || "fallback_secret", {
        expiresIn: (process.env.JWT_EXPIRE || "7d") as any,
    });
};

export const getUserFromRequest = async (req: NextRequest) => {
    try {
        const authHeader = req.headers.get("Authorization");
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return null;
        }

        const token = authHeader.split(" ")[1];
        if (!token) return null;

        const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback_secret") as { id: string };
        if (!decoded || !decoded.id) return null;

        await connectDB();
        const user = await User.findById(decoded.id);
        if (!user) return null;

        return user;
    } catch (error) {
        return null;
    }
};
