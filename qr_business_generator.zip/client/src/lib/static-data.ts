// Static data used throughout the app before backend integration

export const STATIC_USER = {
    id: "usr_1",
    name: "Yaswanth Kumar",
    email: "yaswanth@example.com",
    avatar: null,
    plan: "Pro" as const,
    createdAt: "2024-12-01",
};

export type QRCodeType = "url" | "text" | "vcard" | "wifi" | "email" | "phone";

export interface QRCodeItem {
    id: string;
    name: string;
    type: QRCodeType;
    value: string;
    scans: number;
    createdAt: string;
    color: string;
    bgColor: string;
}

export const QR_TYPES: { value: QRCodeType; label: string; description: string; icon: string }[] = [
    { value: "url", label: "Website URL", description: "Link to any website or webpage", icon: "Globe" },
    { value: "text", label: "Plain Text", description: "Share any text message", icon: "Type" },
    { value: "vcard", label: "Contact Card", description: "Share contact information (vCard)", icon: "Contact" },
    { value: "wifi", label: "Wi-Fi Network", description: "Connect to Wi-Fi instantly", icon: "Wifi" },
    { value: "email", label: "Email Address", description: "Send email with pre-filled data", icon: "Mail" },
    { value: "phone", label: "Phone Number", description: "Direct phone call link", icon: "Phone" },
];

export const STATIC_QR_CODES: QRCodeItem[] = [
    {
        id: "qr_1",
        name: "Company Website",
        type: "url",
        value: "https://qrflow.io",
        scans: 1248,
        createdAt: "2025-01-15",
        color: "#7c3aed",
        bgColor: "#ffffff",
    },
    {
        id: "qr_2",
        name: "Business Card",
        type: "vcard",
        value: "Yaswanth Kumar | CEO | yaswanth@company.com",
        scans: 856,
        createdAt: "2025-02-01",
        color: "#2563eb",
        bgColor: "#ffffff",
    },
    {
        id: "qr_3",
        name: "Office Wi-Fi",
        type: "wifi",
        value: "OfficeNet | WPA2 | ••••••••",
        scans: 342,
        createdAt: "2025-02-10",
        color: "#059669",
        bgColor: "#ffffff",
    },
    {
        id: "qr_4",
        name: "Portfolio Link",
        type: "url",
        value: "https://yaswanth.dev",
        scans: 567,
        createdAt: "2025-02-20",
        color: "#ea580c",
        bgColor: "#ffffff",
    },
    {
        id: "qr_5",
        name: "Support Email",
        type: "email",
        value: "support@qrflow.io",
        scans: 189,
        createdAt: "2025-03-01",
        color: "#dc2626",
        bgColor: "#ffffff",
    },
    {
        id: "qr_6",
        name: "Product Demo",
        type: "url",
        value: "https://demo.qrflow.io",
        scans: 2103,
        createdAt: "2025-03-05",
        color: "#7c3aed",
        bgColor: "#ffffff",
    },
];

export const DASHBOARD_STATS = [
    { label: "Total QR Codes", value: "24", change: "+12%", trend: "up" as const },
    { label: "Total Scans", value: "5,305", change: "+23%", trend: "up" as const },
    { label: "Active Links", value: "18", change: "+6%", trend: "up" as const },
    { label: "Avg. Scans/Day", value: "87", change: "-3%", trend: "down" as const },
];

export const PRICING_PLANS = [
    {
        name: "Free",
        price: "$0",
        period: "forever",
        description: "Perfect for personal use",
        features: [
            "5 Static QR Codes",
            "Basic customization",
            "PNG downloads",
            "Community support",
        ],
        cta: "Get Started",
        popular: false,
    },
    {
        name: "Pro",
        price: "$12",
        period: "per month",
        description: "Best for professionals & teams",
        features: [
            "Unlimited QR Codes",
            "Dynamic QR Codes",
            "Full customization & branding",
            "SVG & PNG downloads",
            "Scan analytics",
            "Priority support",
        ],
        cta: "Start Free Trial",
        popular: true,
    },
    {
        name: "Enterprise",
        price: "$49",
        period: "per month",
        description: "For large-scale deployments",
        features: [
            "Everything in Pro",
            "API access",
            "Team management",
            "Custom domains",
            "White-label solution",
            "Dedicated account manager",
        ],
        cta: "Contact Sales",
        popular: false,
    },
];

export const FAQ_ITEMS = [
    {
        question: "What is a dynamic QR code?",
        answer: "A dynamic QR code allows you to change the destination URL even after the code has been printed. This means you never need to reprint your materials when your link changes.",
    },
    {
        question: "Can I track how many people scan my QR code?",
        answer: "Yes! With our Pro and Enterprise plans, you get detailed scan analytics including total scans, location data, device types, and time-based patterns.",
    },
    {
        question: "What file formats can I download?",
        answer: "Free users can download QR codes as PNG files. Pro and Enterprise users can also download in SVG format for perfect quality at any size.",
    },
    {
        question: "Is there a limit on how many QR codes I can create?",
        answer: "Free accounts can create up to 5 static QR codes. Pro and Enterprise plans include unlimited QR code creation.",
    },
    {
        question: "Can I put my logo in the QR code?",
        answer: "Absolutely! Our customization tools let you add your logo, change colors, adjust corners, and create QR codes that match your brand identity.",
    },
];
