// ══════════════════════════════════════
// API Utility — connects frontend to backend
// ══════════════════════════════════════

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "/api";

/**
 * Get the stored auth token
 */
export function getToken(): string | null {
    if (typeof window === "undefined") return null;
    return localStorage.getItem("qrflow_token");
}

/**
 * Set the auth token
 */
export function setToken(token: string): void {
    localStorage.setItem("qrflow_token", token);
}

/**
 * Remove the auth token
 */
export function removeToken(): void {
    localStorage.removeItem("qrflow_token");
}

/**
 * Generic fetch wrapper with auth headers
 */
async function apiFetch<T = unknown>(
    endpoint: string,
    options: RequestInit = {}
): Promise<T> {
    const token = getToken();
    const headers: Record<string, string> = {
        "Content-Type": "application/json",
        ...(options.headers as Record<string, string>),
    };

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers,
        credentials: "include",
    });

    const data = await res.json();

    if (!res.ok) {
        throw new Error(data.message || "Something went wrong");
    }

    return data as T;
}

// ══════════════════════════════════════
// Auth API
// ══════════════════════════════════════

interface AuthResponse {
    success: boolean;
    message: string;
    data: {
        user: {
            id: string;
            name: string;
            email: string;
            avatar: string | null;
            plan: "Free" | "Pro" | "Enterprise";
            company?: string;
            role?: string;
            createdAt: string;
        };
        token: string;
    };
}

interface MeResponse {
    success: boolean;
    data: {
        id: string;
        name: string;
        email: string;
        avatar: string | null;
        plan: "Free" | "Pro" | "Enterprise";
        company?: string;
        role?: string;
        createdAt: string;
    };
}

export const authAPI = {
    register: (name: string, email: string, password: string) =>
        apiFetch<AuthResponse>("/auth/register", {
            method: "POST",
            body: JSON.stringify({ name, email, password }),
        }),

    login: (email: string, password: string) =>
        apiFetch<AuthResponse>("/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, password }),
        }),

    getMe: () => apiFetch<MeResponse>("/auth/me"),

    updateProfile: (data: { name?: string; company?: string; role?: string }) =>
        apiFetch("/auth/update-profile", {
            method: "PUT",
            body: JSON.stringify(data),
        }),

    changePassword: (currentPassword: string, newPassword: string) =>
        apiFetch("/auth/change-password", {
            method: "PUT",
            body: JSON.stringify({ currentPassword, newPassword }),
        }),
};

// ══════════════════════════════════════
// QR Code API
// ══════════════════════════════════════

export interface QRCodeData {
    _id: string;
    user: string;
    name: string;
    type: string;
    value: string;
    color: string;
    bgColor: string;
    cornerStyle: string;
    logo: string | null;
    scans: number;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}

interface QRCodeListResponse {
    success: boolean;
    data: QRCodeData[];
    pagination: {
        total: number;
        page: number;
        pages: number;
    };
}

interface QRCodeSingleResponse {
    success: boolean;
    data: QRCodeData;
    message?: string;
}

interface StatsResponse {
    success: boolean;
    data: {
        totalQRCodes: number;
        totalScans: number;
        activeLinks: number;
        avgScansPerDay: number;
    };
}

export const qrCodeAPI = {
    create: (data: {
        name: string;
        type: string;
        value: string;
        color?: string;
        bgColor?: string;
        cornerStyle?: string;
    }) =>
        apiFetch<QRCodeSingleResponse>("/qrcodes", {
            method: "POST",
            body: JSON.stringify(data),
        }),

    getAll: (params?: { type?: string; sort?: string; page?: number; limit?: number }) => {
        const query = new URLSearchParams();
        if (params?.type) query.set("type", params.type);
        if (params?.sort) query.set("sort", params.sort);
        if (params?.page) query.set("page", String(params.page));
        if (params?.limit) query.set("limit", String(params.limit));
        const qs = query.toString();
        return apiFetch<QRCodeListResponse>(`/qrcodes${qs ? `?${qs}` : ""}`);
    },

    getOne: (id: string) => apiFetch<QRCodeSingleResponse>(`/qrcodes/${id}`),

    update: (id: string, data: Partial<{
        name: string;
        value: string;
        color: string;
        bgColor: string;
        cornerStyle: string;
        isActive: boolean;
    }>) =>
        apiFetch<QRCodeSingleResponse>(`/qrcodes/${id}`, {
            method: "PUT",
            body: JSON.stringify(data),
        }),

    delete: (id: string) =>
        apiFetch<{ success: boolean; message: string }>(`/qrcodes/${id}`, {
            method: "DELETE",
        }),

    getStats: () => apiFetch<StatsResponse>("/qrcodes/stats"),
};
