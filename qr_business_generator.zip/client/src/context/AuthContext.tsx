"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { authAPI, getToken, setToken, removeToken } from "@/lib/api";

interface User {
    id: string;
    name: string;
    email: string;
    avatar: string | null;
    plan: "Free" | "Pro" | "Enterprise";
    company?: string;
    role?: string;
}

interface AuthContextType {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    login: (email: string, password: string) => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    // On mount, check if we have a token and fetch user profile
    useEffect(() => {
        const initAuth = async () => {
            const token = getToken();
            if (token) {
                try {
                    const res = await authAPI.getMe();
                    setUser({
                        id: res.data.id,
                        name: res.data.name,
                        email: res.data.email,
                        avatar: res.data.avatar,
                        plan: res.data.plan,
                        company: res.data.company,
                        role: res.data.role,
                    });
                } catch {
                    // Token is invalid, clear it
                    removeToken();
                    localStorage.removeItem("qrflow_user");
                }
            }
            setIsLoading(false);
        };
        initAuth();
    }, []);

    const login = async (email: string, password: string) => {
        setIsLoading(true);
        try {
            const res = await authAPI.login(email, password);
            // Store token
            setToken(res.data.token);
            // Store user
            const userData: User = {
                id: res.data.user.id,
                name: res.data.user.name,
                email: res.data.user.email,
                avatar: res.data.user.avatar,
                plan: res.data.user.plan,
            };
            setUser(userData);
            localStorage.setItem("qrflow_user", JSON.stringify(userData));
        } finally {
            setIsLoading(false);
        }
    };

    const register = async (name: string, email: string, password: string) => {
        setIsLoading(true);
        try {
            const res = await authAPI.register(name, email, password);
            // Store token
            setToken(res.data.token);
            // Store user
            const userData: User = {
                id: res.data.user.id,
                name: res.data.user.name,
                email: res.data.user.email,
                avatar: res.data.user.avatar,
                plan: res.data.user.plan,
            };
            setUser(userData);
            localStorage.setItem("qrflow_user", JSON.stringify(userData));
        } finally {
            setIsLoading(false);
        }
    };

    const logout = () => {
        setUser(null);
        removeToken();
        localStorage.removeItem("qrflow_user");
    };

    return (
        <AuthContext.Provider
            value={{ user, isAuthenticated: !!user, isLoading, login, register, logout }}
        >
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
