import Link from "next/link";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import {
  ArrowRight,
  Paintbrush,
  Zap,
  BarChart3,
  Shield,
  Globe,
  Smartphone,
  Check,
  ChevronDown,
  QrCode,
  Star,
} from "lucide-react";
import { PRICING_PLANS, FAQ_ITEMS } from "@/lib/static-data";

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="flex-1">

        {/* ═══════════════════════ HERO ═══════════════════════ */}
        <section className="relative overflow-hidden pt-28 pb-20 lg:pt-40 lg:pb-32 hero-grid">
          {/* Gradient Blob Background */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-gradient-to-br from-violet-500/20 via-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

          <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-5xl">
            {/* Badge */}
            <div className="animate-fade-in-up inline-flex items-center rounded-full border border-violet-200 dark:border-violet-500/20 bg-violet-50 dark:bg-violet-500/10 px-4 py-1.5 text-sm font-medium text-violet-700 dark:text-violet-400 mb-8 gap-2">
              <span className="flex h-2 w-2 rounded-full bg-violet-600 dark:bg-violet-400 animate-pulse"></span>
              Trusted by 10,000+ businesses worldwide
            </div>

            {/* Heading */}
            <h1 className="animate-fade-in-up-delay-1 text-5xl font-extrabold tracking-tight sm:text-6xl md:text-7xl lg:text-[5.5rem] leading-[1.1] mb-8">
              Create QR Codes
              <br />
              <span className="gradient-text">That Convert.</span>
            </h1>

            {/* Subheading */}
            <p className="animate-fade-in-up-delay-2 max-w-2xl text-lg sm:text-xl text-muted-foreground mx-auto mb-10 leading-relaxed">
              Design stunning, customizable QR codes for your business.
              Track scans in real-time. Update links without reprinting. All in one platform.
            </p>

            {/* CTA Buttons */}
            <div className="animate-fade-in-up-delay-3 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/register"
                className="inline-flex h-13 items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-8 text-base font-semibold text-white shadow-lg shadow-violet-500/25 transition-all duration-300 hover:shadow-xl hover:shadow-violet-500/30 hover:scale-[1.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring gap-2 w-full sm:w-auto"
              >
                Start Creating — Free
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="/login"
                className="inline-flex h-13 items-center justify-center rounded-xl border border-border bg-card/50 backdrop-blur-sm px-8 text-base font-semibold text-foreground shadow-sm transition-all duration-300 hover:bg-card hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring w-full sm:w-auto"
              >
                View Demo Dashboard
              </Link>
            </div>

            {/* Social Proof */}
            <div className="mt-12 flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <div className="flex -space-x-2">
                {[
                  "bg-violet-500",
                  "bg-blue-500",
                  "bg-emerald-500",
                  "bg-amber-500",
                ].map((color, i) => (
                  <div
                    key={i}
                    className={`w-8 h-8 rounded-full ${color} border-2 border-background flex items-center justify-center text-white text-xs font-bold`}
                  >
                    {String.fromCharCode(65 + i)}
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-1 ml-2">
                {Array(5).fill(0).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="ml-1">4.9/5 from 2,000+ reviews</span>
            </div>
          </div>
        </section>

        {/* ═══════════════════════ FEATURES ═══════════════════════ */}
        <section id="features" className="py-24 lg:py-32 relative">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
            <div className="text-center mb-16">
              <p className="text-sm font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-widest mb-4">
                Features
              </p>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
                Everything you need to succeed
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From creation to analytics, QRFlow gives your business the edge with feature-rich QR code management.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                icon={<Paintbrush className="h-6 w-6" />}
                color="text-violet-600 bg-violet-50 dark:bg-violet-500/10 dark:text-violet-400"
                title="Full Customization"
                description="Add logos, use your brand colors, and pick unique corner styles. Make your QR codes unmistakably yours."
              />
              <FeatureCard
                icon={<Zap className="h-6 w-6" />}
                color="text-amber-600 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-400"
                title="Dynamic Links"
                description="Change your QR code destination anytime without reprinting. Perfect for campaigns and seasonal offers."
              />
              <FeatureCard
                icon={<BarChart3 className="h-6 w-6" />}
                color="text-blue-600 bg-blue-50 dark:bg-blue-500/10 dark:text-blue-400"
                title="Scan Analytics"
                description="Track scans in real-time with detailed reports on location, devices, and conversion patterns."
              />
              <FeatureCard
                icon={<Globe className="h-6 w-6" />}
                color="text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400"
                title="Multiple Content Types"
                description="Create QR codes for URLs, vCards, Wi-Fi, email, phone numbers, and more — all in one platform."
              />
              <FeatureCard
                icon={<Shield className="h-6 w-6" />}
                color="text-rose-600 bg-rose-50 dark:bg-rose-500/10 dark:text-rose-400"
                title="Enterprise Security"
                description="Your data is encrypted and secure. GDPR compliant with role-based access for teams."
              />
              <FeatureCard
                icon={<Smartphone className="h-6 w-6" />}
                color="text-cyan-600 bg-cyan-50 dark:bg-cyan-500/10 dark:text-cyan-400"
                title="Works Everywhere"
                description="Our QR codes work on every device and scanner. Export as SVG or PNG in any resolution."
              />
            </div>
          </div>
        </section>

        {/* ═══════════════════════ STATS BANNER ═══════════════════════ */}
        <section className="py-16 bg-gradient-to-r from-violet-600 to-indigo-600 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.05%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] opacity-50" />

          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
              {[
                { value: "10K+", label: "Businesses" },
                { value: "2M+", label: "QR Codes Created" },
                { value: "50M+", label: "Total Scans" },
                { value: "99.9%", label: "Uptime" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-4xl sm:text-5xl font-extrabold mb-2">{stat.value}</div>
                  <div className="text-sm sm:text-base text-white/70 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════ PRICING ═══════════════════════ */}
        <section id="pricing" className="py-24 lg:py-32 relative">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
            <div className="text-center mb-16">
              <p className="text-sm font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-widest mb-4">
                Pricing
              </p>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
                Simple, transparent pricing
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Start free, upgrade when you&apos;re ready. No hidden fees, cancel anytime.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-start">
              {PRICING_PLANS.map((plan) => (
                <div
                  key={plan.name}
                  className={`relative rounded-2xl p-8 transition-all duration-300 ${plan.popular
                      ? "bg-gradient-to-b from-violet-600 to-indigo-700 text-white shadow-2xl shadow-violet-500/20 scale-[1.02] border-0 ring-1 ring-violet-500/30"
                      : "bg-card border border-border shadow-sm hover:shadow-md"
                    }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="bg-amber-400 text-amber-900 text-xs font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-md">
                        Most Popular
                      </span>
                    </div>
                  )}

                  <h3 className={`text-lg font-semibold mb-2 ${plan.popular ? "text-white" : "text-foreground"}`}>
                    {plan.name}
                  </h3>
                  <p className={`text-sm mb-6 ${plan.popular ? "text-white/70" : "text-muted-foreground"}`}>
                    {plan.description}
                  </p>

                  <div className="flex items-baseline gap-1 mb-8">
                    <span className="text-5xl font-extrabold">{plan.price}</span>
                    <span className={`text-sm ${plan.popular ? "text-white/60" : "text-muted-foreground"}`}>
                      /{plan.period}
                    </span>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3 text-sm">
                        <Check className={`h-5 w-5 flex-shrink-0 mt-0.5 ${plan.popular ? "text-emerald-300" : "text-violet-600 dark:text-violet-400"}`} />
                        <span className={plan.popular ? "text-white/90" : "text-foreground"}>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link
                    href="/register"
                    className={`flex h-11 items-center justify-center rounded-xl text-sm font-semibold transition-all duration-200 w-full ${plan.popular
                        ? "bg-white text-violet-700 hover:bg-white/90 shadow-md"
                        : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm"
                      }`}
                  >
                    {plan.cta}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════ FAQ ═══════════════════════ */}
        <section id="faq" className="py-24 lg:py-32 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
            <div className="text-center mb-16">
              <p className="text-sm font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-widest mb-4">
                FAQ
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
                Frequently asked questions
              </h2>
            </div>

            <div className="space-y-4">
              {FAQ_ITEMS.map((item, i) => (
                <details
                  key={i}
                  className="group bg-card border border-border rounded-xl overflow-hidden shadow-sm"
                >
                  <summary className="flex items-center justify-between p-5 cursor-pointer text-foreground font-medium hover:bg-muted/30 transition-colors select-none">
                    <span>{item.question}</span>
                    <ChevronDown className="h-5 w-5 text-muted-foreground transition-transform duration-200 group-open:rotate-180" />
                  </summary>
                  <div className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">
                    {item.answer}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════ CTA BANNER ═══════════════════════ */}
        <section className="py-24 lg:py-32 relative overflow-hidden">
          <div className="absolute inset-0 hero-grid" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-gradient-to-br from-violet-500/15 via-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

          <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-3xl">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 shadow-lg shadow-violet-500/20 mb-8">
              <QrCode className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-6">
              Ready to create your first QR code?
            </h2>
            <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
              Join thousands of businesses that trust QRFlow for their QR code needs.
              Start free, upgrade when you grow.
            </p>
            <Link
              href="/register"
              className="inline-flex h-13 items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-10 text-base font-semibold text-white shadow-lg shadow-violet-500/25 transition-all duration-300 hover:shadow-xl hover:shadow-violet-500/30 hover:scale-[1.03] gap-2"
            >
              Get Started — It&apos;s Free
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function FeatureCard({
  icon,
  color,
  title,
  description,
}: {
  icon: React.ReactNode;
  color: string;
  title: string;
  description: string;
}) {
  return (
    <div className="group p-6 rounded-2xl bg-card border border-border/50 shadow-sm transition-all duration-300 hover:shadow-md hover:border-border hover:-translate-y-0.5">
      <div className={`h-12 w-12 rounded-xl ${color} flex items-center justify-center mb-5 transition-transform duration-300 group-hover:scale-110`}>
        {icon}
      </div>
      <h3 className="text-lg font-bold mb-2 text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}
