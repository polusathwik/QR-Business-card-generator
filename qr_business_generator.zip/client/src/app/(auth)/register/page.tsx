"use client";

import Link from "next/link";
import { useState } from "react";
import { QrCode, Eye, EyeOff, ArrowRight, Chrome, Check } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export default function RegisterPage() {
    const [showPassword, setShowPassword] = useState(false);
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");
    const { register } = useAuth();

    const passwordChecks = [
        { label: "At least 8 characters", met: password.length >= 8 },
        { label: "Contains a number", met: /\d/.test(password) },
        { label: "Contains uppercase letter", met: /[A-Z]/.test(password) },
    ];

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError("");
        try {
            await register(name, email, password);
            window.location.href = "/dashboard";
        } catch (err: unknown) {
            const message = err instanceof Error ? err.message : "Registration failed. Please try again.";
            setError(message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex">
            {/* Left - Visual Side */}
            <div className="hidden lg:flex flex-1 bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.06%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] opacity-50" />

                <div className="relative text-center px-12">
                    <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-white/10 backdrop-blur-sm mb-8 border border-white/20">
                        <QrCode className="h-10 w-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-4 max-w-md">
                        Start generating professional QR codes today
                    </h2>
                    <p className="text-white/70 text-lg max-w-sm mx-auto mb-10">
                        Free forever with 5 QR codes. Upgrade anytime for unlimited access.
                    </p>
                    <div className="space-y-3 text-left max-w-xs mx-auto">
                        {["No credit card required", "5 free QR codes", "Full customization"].map((item) => (
                            <div key={item} className="flex items-center gap-3 text-white/90 text-sm">
                                <div className="h-5 w-5 rounded-full bg-emerald-400/20 flex items-center justify-center">
                                    <Check className="h-3 w-3 text-emerald-300" />
                                </div>
                                {item}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right - Form Side */}
            <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-20 max-w-xl mx-auto w-full">
                {/* Logo */}
                <Link href="/" className="flex items-center gap-2.5 mb-12">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 shadow-sm shadow-violet-500/20">
                        <QrCode className="h-5 w-5 text-white" />
                    </div>
                    <span className="text-xl font-bold tracking-tight">
                        QR<span className="text-violet-600 dark:text-violet-400">Flow</span>
                    </span>
                </Link>

                <div className="mb-8">
                    <h1 className="text-3xl font-bold tracking-tight mb-2">Create your account</h1>
                    <p className="text-muted-foreground">
                        Get started with QRFlow — it&apos;s free
                    </p>
                </div>

                {/* Error Message */}
                {error && (
                    <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm font-medium">
                        {error}
                    </div>
                )}

                {/* Google Auth */}
                <button className="flex items-center justify-center gap-3 w-full h-11 rounded-xl border border-border bg-card text-sm font-medium text-foreground shadow-sm transition-all duration-200 hover:bg-muted hover:shadow-md mb-6">
                    <Chrome className="h-5 w-5" />
                    Sign up with Google
                </button>

                {/* Divider */}
                <div className="relative mb-6">
                    <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-border" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-background px-3 text-muted-foreground font-medium">or continue with email</span>
                    </div>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                            Full name
                        </label>
                        <input
                            id="name"
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="John Doe"
                            required
                            className="w-full h-11 rounded-xl border border-input bg-card px-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200"
                        />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                            Email address
                        </label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@company.com"
                            required
                            className="w-full h-11 rounded-xl border border-input bg-card px-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-foreground mb-2">
                            Password
                        </label>
                        <div className="relative">
                            <input
                                id="password"
                                type={showPassword ? "text" : "password"}
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Create a strong password"
                                required
                                className="w-full h-11 rounded-xl border border-input bg-card px-4 pr-11 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                            >
                                {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                            </button>
                        </div>
                        {/* Password Strength */}
                        {password.length > 0 && (
                            <div className="mt-3 space-y-1.5">
                                {passwordChecks.map((check) => (
                                    <div key={check.label} className="flex items-center gap-2 text-xs">
                                        <div className={`h-4 w-4 rounded-full flex items-center justify-center ${check.met ? "bg-emerald-100 dark:bg-emerald-500/20" : "bg-muted"}`}>
                                            <Check className={`h-2.5 w-2.5 ${check.met ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground/40"}`} />
                                        </div>
                                        <span className={check.met ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"}>
                                            {check.label}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full h-11 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-sm font-semibold text-white shadow-md shadow-violet-500/20 transition-all duration-200 hover:shadow-lg hover:shadow-violet-500/30 hover:scale-[1.01] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                        {isLoading ? (
                            <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                            <>
                                Create Account
                                <ArrowRight className="w-4 h-4" />
                            </>
                        )}
                    </button>
                </form>

                <p className="mt-6 text-xs text-muted-foreground text-center">
                    By creating an account, you agree to our{" "}
                    <Link href="#" className="underline hover:text-foreground">Terms</Link>{" "}
                    and{" "}
                    <Link href="#" className="underline hover:text-foreground">Privacy Policy</Link>.
                </p>

                <p className="mt-6 text-sm text-muted-foreground text-center">
                    Already have an account?{" "}
                    <Link href="/login" className="font-semibold text-violet-600 dark:text-violet-400 hover:underline">
                        Sign in
                    </Link>
                </p>
            </div>
        </div>
    );
}
