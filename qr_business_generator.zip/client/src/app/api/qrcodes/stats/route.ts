import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import QRCode from "@/models/QRCode";

export async function GET(req: NextRequest) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const userId = user._id;

        const [totalQR, totalScans, activeLinks] = await Promise.all([
            QRCode.countDocuments({ user: userId }),
            QRCode.aggregate([
                { $match: { user: userId } },
                { $group: { _id: null, totalScans: { $sum: "$scans" } } },
            ]),
            QRCode.countDocuments({ user: userId, isActive: true }),
        ]);

        const scans = totalScans.length > 0 ? totalScans[0].totalScans : 0;

        return NextResponse.json({
            success: true,
            data: {
                totalQRCodes: totalQR,
                totalScans: scans,
                activeLinks,
                avgScansPerDay: totalQR > 0 ? Math.round(scans / 30) : 0,
            },
        }, { status: 200 });
    } catch (error) {
        console.error("GetDashboardStats Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
