import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import QRCode from "@/models/QRCode";

export async function POST(req: NextRequest) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const body = await req.json();
        const { name, type, value, color, bgColor, cornerStyle } = body;

        if (!name || !type || !value) {
            return NextResponse.json({
                success: false,
                message: "Name, type, and value are required.",
            }, { status: 400 });
        }

        // Check plan limits for free users
        if (user.plan === "Free") {
            const count = await QRCode.countDocuments({ user: user._id });
            if (count >= 5) {
                return NextResponse.json({
                    success: false,
                    message: "Free plan limit reached (5 QR codes). Upgrade to Pro for unlimited QR codes.",
                }, { status: 403 });
            }
        }

        const qrCode = await QRCode.create({
            user: user._id,
            name,
            type,
            value,
            color: color || "#7c3aed",
            bgColor: bgColor || "#ffffff",
            cornerStyle: cornerStyle || "rounded",
        });

        return NextResponse.json({
            success: true,
            message: "QR code created successfully!",
            data: qrCode,
        }, { status: 201 });
    } catch (error) {
        console.error("CreateQRCode Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}

export async function GET(req: NextRequest) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const searchParams = req.nextUrl.searchParams;
        const type = searchParams.get("type");
        const sort = searchParams.get("sort") || "-createdAt";
        const page = parseInt(searchParams.get("page") || "1");
        const limit = parseInt(searchParams.get("limit") || "20");

        const filter: any = { user: user._id };
        if (type) filter.type = type;

        const skip = (page - 1) * limit;

        const [qrCodes, total] = await Promise.all([
            QRCode.find(filter)
                .sort(sort)
                .skip(skip)
                .limit(limit),
            QRCode.countDocuments(filter),
        ]);

        return NextResponse.json({
            success: true,
            data: qrCodes,
            pagination: {
                total,
                page,
                pages: Math.ceil(total / limit),
            },
        }, { status: 200 });
    } catch (error) {
        console.error("GetQRCodes Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
