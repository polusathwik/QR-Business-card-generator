import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import QRCode from "@/models/QRCode";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
    try {
        await connectDB();
        const { id } = await params;

        const qrCode = await QRCode.findByIdAndUpdate(
            id,
            { $inc: { scans: 1 } },
            { new: true }
        );

        if (!qrCode) {
            return NextResponse.json({
                success: false,
                message: "QR code not found.",
            }, { status: 404 });
        }

        // Return redirect URL or data based on type
        // The client API call will handle the actual redirect if needed
        return NextResponse.json({
            success: true,
            data: { value: qrCode.value, type: qrCode.type }
        }, { status: 200 });
    } catch (error) {
        console.error("RecordScan Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
