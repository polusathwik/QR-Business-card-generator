import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import QRCode from "@/models/QRCode";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);
        const { id } = await params;

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const qrCode = await QRCode.findOne({
            _id: id,
            user: user._id,
        });

        if (!qrCode) {
            return NextResponse.json({
                success: false,
                message: "QR code not found.",
            }, { status: 404 });
        }

        return NextResponse.json({ success: true, data: qrCode }, { status: 200 });
    } catch (error) {
        console.error("GetQRCode Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);
        const { id } = await params;

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const body = await req.json();
        const { name, value, color, bgColor, cornerStyle, isActive } = body;

        const qrCode = await QRCode.findOneAndUpdate(
            { _id: id, user: user._id },
            { name, value, color, bgColor, cornerStyle, isActive },
            { new: true, runValidators: true }
        );

        if (!qrCode) {
            return NextResponse.json({
                success: false,
                message: "QR code not found.",
            }, { status: 404 });
        }

        return NextResponse.json({
            success: true,
            message: "QR code updated successfully!",
            data: qrCode,
        }, { status: 200 });
    } catch (error) {
        console.error("UpdateQRCode Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);
        const { id } = await params;

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const qrCode = await QRCode.findOneAndDelete({
            _id: id,
            user: user._id,
        });

        if (!qrCode) {
            return NextResponse.json({
                success: false,
                message: "QR code not found.",
            }, { status: 404 });
        }

        return NextResponse.json({
            success: true,
            message: "QR code deleted successfully!",
        }, { status: 200 });
    } catch (error) {
        console.error("DeleteQRCode Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
