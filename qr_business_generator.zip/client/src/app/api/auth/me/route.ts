import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        return NextResponse.json({
            success: true,
            data: {
                id: user._id,
                name: user.name,
                email: user.email,
                avatar: user.avatar,
                plan: user.plan,
                company: user.company,
                role: user.role,
                createdAt: user.createdAt,
            },
        }, { status: 200 });
    } catch (error) {
        console.error("GetMe Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
