import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest, generateToken } from "@/lib/auth";
import User from "@/models/User";

export async function PUT(req: NextRequest) {
    try {
        await connectDB();
        const authedUser = await getUserFromRequest(req);

        if (!authedUser) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const body = await req.json();
        const { currentPassword, newPassword } = body;

        const user = await User.findById(authedUser._id).select("+password");

        // Check current password
        const isMatch = await user.comparePassword(currentPassword);
        if (!isMatch) {
            return NextResponse.json({
                success: false,
                message: "Current password is incorrect.",
            }, { status: 400 });
        }

        user.password = newPassword;
        await user.save();

        const token = generateToken(user._id.toString());

        return NextResponse.json({
            success: true,
            message: "Password changed successfully!",
            data: { token },
        }, { status: 200 });
    } catch (error) {
        console.error("ChangePassword Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
