import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";

export async function PUT(req: NextRequest) {
    try {
        await connectDB();
        const user = await getUserFromRequest(req);

        if (!user) {
            return NextResponse.json({ success: false, message: "Not authorized" }, { status: 401 });
        }

        const body = await req.json();
        const { name, company, role } = body;

        user.name = name || user.name;
        user.company = company || user.company;
        user.role = role || user.role;

        await user.save();

        return NextResponse.json({
            success: true,
            message: "Profile updated successfully!",
            data: {
                id: user._id,
                name: user.name,
                email: user.email,
                avatar: user.avatar,
                plan: user.plan,
                company: user.company,
                role: user.role,
            },
        }, { status: 200 });
    } catch (error) {
        console.error("UpdateProfile Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
