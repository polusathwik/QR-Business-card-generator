import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import User from "@/models/User";
import { generateToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
    try {
        await connectDB();
        const body = await req.json();
        const { name, email, password } = body;

        if (!name || !email || !password) {
            return NextResponse.json({ success: false, message: "Please provide all required fields" }, { status: 400 });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return NextResponse.json({
                success: false,
                message: "A user with this email already exists.",
            }, { status: 400 });
        }

        // Create user
        const user = await User.create({ name, email, password });

        // Generate token
        const token = generateToken(user._id.toString());

        return NextResponse.json({
            success: true,
            message: "Account created successfully!",
            data: {
                user: {
                    id: user._id,
                    name: user.name,
                    email: user.email,
                    avatar: user.avatar,
                    plan: user.plan,
                    createdAt: user.createdAt,
                },
                token,
            },
        }, { status: 201 });
    } catch (error) {
        console.error("Register Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
