import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import User from "@/models/User";
import { generateToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
    try {
        await connectDB();
        const body = await req.json();
        const { email, password } = body;

        if (!email || !password) {
            return NextResponse.json({ success: false, message: "Please provide email and password" }, { status: 400 });
        }

        // Get user with password included
        const user = await User.findOne({ email }).select("+password");
        if (!user) {
            return NextResponse.json({
                success: false,
                message: "Invalid email or password.",
            }, { status: 401 });
        }

        // Check password
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return NextResponse.json({
                success: false,
                message: "Invalid email or password.",
            }, { status: 401 });
        }

        // Generate token
        const token = generateToken(user._id.toString());

        return NextResponse.json({
            success: true,
            message: "Logged in successfully!",
            data: {
                user: {
                    id: user._id,
                    name: user.name,
                    email: user.email,
                    avatar: user.avatar,
                    plan: user.plan,
                    createdAt: user.createdAt,
                },
                token,
            },
        }, { status: 200 });
    } catch (error: any) {
        console.error("Login Error:", error);
        return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
    }
}
