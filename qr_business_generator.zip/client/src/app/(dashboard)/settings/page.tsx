"use client";

import { useState } from "react";
import { User, Mail, Lock, Bell, Eye, EyeOff, Shield, Palette, Save, Check } from "lucide-react";
import { cn } from "@/lib/utils";

const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "security", label: "Security", icon: Shield },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "appearance", label: "Appearance", icon: Palette },
];

export default function SettingsPage() {
    const [activeTab, setActiveTab] = useState("profile");
    const [showOldPassword, setShowOldPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [saved, setSaved] = useState(false);

    const handleSave = () => {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
    };

    return (
        <div className="p-6 lg:p-8 max-w-4xl">
            {/* Header */}
            <div className="mb-8">
                <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
                <p className="text-sm text-muted-foreground mt-1">
                    Manage your account settings and preferences.
                </p>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 p-1 bg-muted/50 rounded-xl mb-8 overflow-x-auto">
                {tabs.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={cn(
                            "flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap",
                            activeTab === tab.id
                                ? "bg-card text-foreground shadow-sm"
                                : "text-muted-foreground hover:text-foreground"
                        )}
                    >
                        <tab.icon className="h-4 w-4" />
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Profile Tab */}
            {activeTab === "profile" && (
                <div className="space-y-6">
                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                        <h3 className="text-base font-semibold mb-5">Profile Information</h3>

                        <div className="flex items-center gap-5 mb-8">
                            <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-violet-500/20">
                                Y
                            </div>
                            <div>
                                <button className="text-sm font-medium text-violet-600 dark:text-violet-400 hover:underline">
                                    Change avatar
                                </button>
                                <p className="text-xs text-muted-foreground mt-1">JPG, PNG or GIF. Max 2MB.</p>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label className="block text-sm font-medium mb-2">Full name</label>
                                <input
                                    type="text"
                                    defaultValue="Yaswanth Kumar"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Email</label>
                                <input
                                    type="email"
                                    defaultValue="yaswanth@example.com"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Company</label>
                                <input
                                    type="text"
                                    defaultValue="QRFlow Inc."
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Role</label>
                                <input
                                    type="text"
                                    defaultValue="CEO"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                        <h3 className="text-base font-semibold mb-5">Plan & Billing</h3>
                        <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-violet-50 to-indigo-50 dark:from-violet-500/10 dark:to-indigo-500/10 border border-violet-200 dark:border-violet-500/20">
                            <div>
                                <div className="flex items-center gap-2">
                                    <span className="text-sm font-bold text-violet-700 dark:text-violet-400">Pro Plan</span>
                                    <span className="text-[10px] font-bold uppercase tracking-widest bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-2 py-0.5 rounded-full">
                                        Active
                                    </span>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">$12/month • Renews on April 1, 2025</p>
                            </div>
                            <button className="text-sm font-medium text-violet-600 dark:text-violet-400 hover:underline">
                                Manage
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Security Tab */}
            {activeTab === "security" && (
                <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                    <h3 className="text-base font-semibold mb-5">Change Password</h3>
                    <div className="space-y-5 max-w-md">
                        <div>
                            <label className="block text-sm font-medium mb-2">Current Password</label>
                            <div className="relative">
                                <input
                                    type={showOldPassword ? "text" : "password"}
                                    placeholder="Enter current password"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 pr-11 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowOldPassword(!showOldPassword)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                >
                                    {showOldPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-2">New Password</label>
                            <div className="relative">
                                <input
                                    type={showNewPassword ? "text" : "password"}
                                    placeholder="Enter new password"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 pr-11 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowNewPassword(!showNewPassword)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                >
                                    {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-2">Confirm New Password</label>
                            <input
                                type="password"
                                placeholder="Confirm new password"
                                className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
                            />
                        </div>
                    </div>
                </div>
            )}

            {/* Notifications Tab */}
            {activeTab === "notifications" && (
                <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                    <h3 className="text-base font-semibold mb-5">Notification Preferences</h3>
                    <div className="space-y-5">
                        {[
                            { label: "Scan Alerts", desc: "Get notified when your QR codes are scanned", default: true },
                            { label: "Weekly Reports", desc: "Receive weekly analytics summaries via email", default: true },
                            { label: "Product Updates", desc: "Stay informed about new features and updates", default: false },
                            { label: "Marketing Emails", desc: "Receive tips and promotional content", default: false },
                        ].map((item) => (
                            <div key={item.label} className="flex items-center justify-between py-2">
                                <div>
                                    <p className="text-sm font-medium">{item.label}</p>
                                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" defaultChecked={item.default} className="sr-only peer" />
                                    <div className="w-11 h-6 bg-muted rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-violet-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                                </label>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Appearance Tab */}
            {activeTab === "appearance" && (
                <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                    <h3 className="text-base font-semibold mb-5">Appearance</h3>
                    <div>
                        <label className="block text-sm font-medium mb-3">Theme</label>
                        <div className="grid grid-cols-3 gap-3 max-w-md">
                            {[
                                { id: "light", label: "Light", bg: "bg-white", border: "border-gray-200" },
                                { id: "dark", label: "Dark", bg: "bg-gray-900", border: "border-gray-700" },
                                { id: "system", label: "System", bg: "bg-gradient-to-r from-white to-gray-900", border: "border-gray-400" },
                            ].map((theme) => (
                                <button
                                    key={theme.id}
                                    className={`p-4 rounded-xl border-2 ${theme.border} hover:ring-2 hover:ring-violet-500/20 transition-all text-center`}
                                >
                                    <div className={`h-10 w-full rounded-lg ${theme.bg} border border-border/30 mb-2`} />
                                    <span className="text-xs font-medium">{theme.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Save Button */}
            <div className="mt-8 flex items-center gap-3">
                <button
                    onClick={handleSave}
                    className="inline-flex h-11 items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-6 text-sm font-semibold text-white shadow-md shadow-violet-500/20 transition-all duration-200 hover:shadow-lg hover:scale-[1.01] gap-2"
                >
                    {saved ? (
                        <>
                            <Check className="h-4 w-4" />
                            Saved!
                        </>
                    ) : (
                        <>
                            <Save className="h-4 w-4" />
                            Save Changes
                        </>
                    )}
                </button>
                <button className="h-11 px-6 rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                    Cancel
                </button>
            </div>
        </div>
    );
}
