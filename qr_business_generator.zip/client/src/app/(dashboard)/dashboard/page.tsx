"use client";

import { useState, useEffect } from "react";
import {
    TrendingUp,
    TrendingDown,
    QrCode,
    Plus,
    ExternalLink,
    Copy,
    BarChart3,
    Eye,
    Trash2,
    Loader2,
} from "lucide-react";
import Link from "next/link";
import { qrCodeAPI, type QRCodeData } from "@/lib/api";

interface DashboardStats {
    totalQRCodes: number;
    totalScans: number;
    activeLinks: number;
    avgScansPerDay: number;
}

export default function DashboardPage() {
    const [stats, setStats] = useState<DashboardStats | null>(null);
    const [qrCodes, setQrCodes] = useState<QRCodeData[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [statsRes, qrRes] = await Promise.all([
                    qrCodeAPI.getStats(),
                    qrCodeAPI.getAll({ limit: 10 }),
                ]);
                setStats(statsRes.data);
                setQrCodes(qrRes.data);
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : "Failed to load dashboard data";
                setError(message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleDelete = async (id: string) => {
        if (!confirm("Are you sure you want to delete this QR code?")) return;
        try {
            await qrCodeAPI.delete(id);
            setQrCodes((prev) => prev.filter((qr) => qr._id !== id));
            // Refresh stats
            const statsRes = await qrCodeAPI.getStats();
            setStats(statsRes.data);
        } catch (err: unknown) {
            const message = err instanceof Error ? err.message : "Failed to delete";
            alert(message);
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-[60vh]">
                <div className="flex flex-col items-center gap-3">
                    <Loader2 className="h-8 w-8 text-violet-600 animate-spin" />
                    <p className="text-sm text-muted-foreground">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-6 lg:p-8">
                <div className="bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-2xl p-6 text-center">
                    <p className="text-red-700 dark:text-red-400 font-medium">{error}</p>
                    <p className="text-sm text-red-600/70 dark:text-red-400/70 mt-1">Make sure the backend is running on port 5000 and you are logged in.</p>
                </div>
            </div>
        );
    }

    const dashboardStats = [
        { label: "Total QR Codes", value: String(stats?.totalQRCodes ?? 0), change: "+12%", trend: "up" as const },
        { label: "Total Scans", value: String(stats?.totalScans ?? 0), change: "+23%", trend: "up" as const },
        { label: "Active Links", value: String(stats?.activeLinks ?? 0), change: "+6%", trend: "up" as const },
        { label: "Avg. Scans/Day", value: String(stats?.avgScansPerDay ?? 0), change: "-3%", trend: "down" as const },
    ];

    return (
        <div className="p-6 lg:p-8 space-y-8 max-w-7xl">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
                    <p className="text-sm text-muted-foreground mt-1">
                        Welcome back! Here&apos;s an overview of your QR codes.
                    </p>
                </div>
                <Link
                    href="/generate"
                    className="inline-flex h-10 items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 text-sm font-semibold text-white shadow-md shadow-violet-500/20 transition-all duration-200 hover:shadow-lg hover:shadow-violet-500/30 hover:scale-[1.02] gap-2 w-fit"
                >
                    <Plus className="h-4 w-4" />
                    Create QR Code
                </Link>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {dashboardStats.map((stat) => (
                    <div
                        key={stat.label}
                        className="bg-card rounded-2xl border border-border/50 p-5 shadow-sm hover:shadow-md transition-shadow duration-300"
                    >
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-medium text-muted-foreground">
                                {stat.label}
                            </span>
                            {stat.trend === "up" ? (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400 px-2 py-0.5 rounded-full">
                                    <TrendingUp className="h-3 w-3" />
                                    {stat.change}
                                </span>
                            ) : (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 bg-red-50 dark:bg-red-500/10 dark:text-red-400 px-2 py-0.5 rounded-full">
                                    <TrendingDown className="h-3 w-3" />
                                    {stat.change}
                                </span>
                            )}
                        </div>
                        <div className="text-3xl font-extrabold tracking-tight">{stat.value}</div>
                    </div>
                ))}
            </div>

            {/* QR Codes Table */}
            <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-border/40 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-violet-50 dark:bg-violet-500/10 flex items-center justify-center">
                            <QrCode className="h-5 w-5 text-violet-600 dark:text-violet-400" />
                        </div>
                        <div>
                            <h2 className="text-lg font-semibold">Your QR Codes</h2>
                            <p className="text-xs text-muted-foreground">Manage and track all your QR codes</p>
                        </div>
                    </div>
                    <Link
                        href="/generate"
                        className="text-sm font-medium text-violet-600 dark:text-violet-400 hover:underline"
                    >
                        Create new →
                    </Link>
                </div>

                {qrCodes.length === 0 ? (
                    <div className="p-12 text-center">
                        <QrCode className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-1">No QR codes yet</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                            Create your first QR code to get started.
                        </p>
                        <Link
                            href="/generate"
                            className="inline-flex h-10 items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 text-sm font-semibold text-white shadow-md shadow-violet-500/20 gap-2"
                        >
                            <Plus className="h-4 w-4" />
                            Create QR Code
                        </Link>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-border/40 bg-muted/30">
                                    <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">
                                        QR Code
                                    </th>
                                    <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3 hidden sm:table-cell">
                                        Type
                                    </th>
                                    <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3 hidden md:table-cell">
                                        Created
                                    </th>
                                    <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">
                                        Scans
                                    </th>
                                    <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-border/30">
                                {qrCodes.map((qr) => (
                                    <tr key={qr._id} className="hover:bg-muted/20 transition-colors">
                                        <td className="px-5 py-4">
                                            <div className="flex items-center gap-3">
                                                <div
                                                    className="h-10 w-10 rounded-xl flex items-center justify-center shadow-sm"
                                                    style={{ backgroundColor: qr.color + "15" }}
                                                >
                                                    <QrCode className="h-5 w-5" style={{ color: qr.color }} />
                                                </div>
                                                <div>
                                                    <p className="text-sm font-semibold text-foreground">{qr.name}</p>
                                                    <p className="text-xs text-muted-foreground truncate max-w-[200px]">{qr.value}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-5 py-4 hidden sm:table-cell">
                                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground capitalize">
                                                {qr.type}
                                            </span>
                                        </td>
                                        <td className="px-5 py-4 hidden md:table-cell">
                                            <span className="text-sm text-muted-foreground">
                                                {new Date(qr.createdAt).toLocaleDateString()}
                                            </span>
                                        </td>
                                        <td className="px-5 py-4">
                                            <div className="flex items-center gap-1.5">
                                                <Eye className="h-3.5 w-3.5 text-muted-foreground" />
                                                <span className="text-sm font-semibold">{qr.scans.toLocaleString()}</span>
                                            </div>
                                        </td>
                                        <td className="px-5 py-4 text-right">
                                            <div className="flex items-center justify-end gap-1">
                                                <button
                                                    onClick={() => navigator.clipboard.writeText(qr.value)}
                                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                                                    title="Copy value"
                                                >
                                                    <Copy className="h-4 w-4" />
                                                </button>
                                                {qr.type === "url" && (
                                                    <a
                                                        href={qr.value}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                                                        title="Open link"
                                                    >
                                                        <ExternalLink className="h-4 w-4" />
                                                    </a>
                                                )}
                                                <button
                                                    onClick={() => handleDelete(qr._id)}
                                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
                                                    title="Delete"
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Quick Analytics Card */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="h-10 w-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center">
                            <BarChart3 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold">Scan Activity</h3>
                            <p className="text-xs text-muted-foreground">Last 7 days</p>
                        </div>
                    </div>
                    {/* Simple bar chart visualization */}
                    <div className="flex items-end gap-2 h-32">
                        {[40, 65, 45, 80, 55, 90, 70].map((h, i) => (
                            <div key={i} className="flex-1 flex flex-col items-center gap-1">
                                <div
                                    className="w-full rounded-t-lg bg-gradient-to-t from-violet-600 to-indigo-500 transition-all duration-500 hover:from-violet-500 hover:to-indigo-400"
                                    style={{ height: `${h}%` }}
                                />
                                <span className="text-[10px] text-muted-foreground">
                                    {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][i]}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="h-10 w-10 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 flex items-center justify-center">
                            <TrendingUp className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold">Top Performers</h3>
                            <p className="text-xs text-muted-foreground">Most scanned QR codes</p>
                        </div>
                    </div>
                    <div className="space-y-4">
                        {qrCodes.length === 0 ? (
                            <p className="text-sm text-muted-foreground text-center py-6">
                                No QR codes yet. Create one to see analytics.
                            </p>
                        ) : (
                            [...qrCodes]
                                .sort((a, b) => b.scans - a.scans)
                                .slice(0, 4)
                                .map((qr, i) => (
                                    <div key={qr._id} className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <span className="text-xs font-bold text-muted-foreground w-5">
                                                #{i + 1}
                                            </span>
                                            <div
                                                className="h-8 w-8 rounded-lg flex items-center justify-center"
                                                style={{ backgroundColor: qr.color + "15" }}
                                            >
                                                <QrCode className="h-4 w-4" style={{ color: qr.color }} />
                                            </div>
                                            <span className="text-sm font-medium">{qr.name}</span>
                                        </div>
                                        <span className="text-sm font-semibold">{qr.scans.toLocaleString()} scans</span>
                                    </div>
                                ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
