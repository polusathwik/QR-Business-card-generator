"use client";

import { useState, useRef, useCallback } from "react";
import {
    Globe,
    Type,
    Contact,
    Wifi,
    Mail,
    Phone,
    Download,
    Palette,
    RotateCcw,
    Sparkles,
    Square,
    Circle,
    Save,
    Loader2,
    CheckCircle2,
    AlertCircle,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { QR_TYPES, type QRCodeType } from "@/lib/static-data";
import { cn } from "@/lib/utils";
import { qrCodeAPI } from "@/lib/api";

const iconMap: Record<string, React.ReactNode> = {
    Globe: <Globe className="h-5 w-5" />,
    Type: <Type className="h-5 w-5" />,
    Contact: <Contact className="h-5 w-5" />,
    Wifi: <Wifi className="h-5 w-5" />,
    Mail: <Mail className="h-5 w-5" />,
    Phone: <Phone className="h-5 w-5" />,
};

const presetColors = [
    "#7c3aed", "#2563eb", "#059669", "#ea580c",
    "#dc2626", "#d946ef", "#0891b2", "#18181b",
];

export default function GeneratePage() {
    const [selectedType, setSelectedType] = useState<QRCodeType>("url");
    const [inputValue, setInputValue] = useState("https://");
    const [qrColor, setQrColor] = useState("#7c3aed");
    const [bgColor, setBgColor] = useState("#ffffff");
    const [qrName, setQrName] = useState("");
    const [cornerStyle, setCornerStyle] = useState<"square" | "rounded">("rounded");
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isGenerated, setIsGenerated] = useState(false);
    const [saveStatus, setSaveStatus] = useState<"idle" | "success" | "error">("idle");
    const [statusMessage, setStatusMessage] = useState("");
    const qrRef = useRef<HTMLDivElement>(null);

    const getPlaceholder = () => {
        switch (selectedType) {
            case "url": return "https://example.com";
            case "text": return "Enter your text message...";
            case "vcard": return "Full Name, Email, Phone, Company";
            case "wifi": return "Network Name | Password | WPA2";
            case "email": return "email@example.com";
            case "phone": return "+1 234 567 8900";
            default: return "";
        }
    };

    // Build the actual QR value based on type
    const getQRValue = useCallback(() => {
        switch (selectedType) {
            case "url":
                return inputValue;
            case "email":
                return `mailto:${inputValue}`;
            case "phone":
                return `tel:${inputValue}`;
            case "wifi": {
                // Parse: "NetworkName | Password | WPA2"
                const parts = inputValue.split("|").map((p) => p.trim());
                const ssid = parts[0] || "";
                const pass = parts[1] || "";
                const security = parts[2] || "WPA";
                return `WIFI:T:${security};S:${ssid};P:${pass};;`;
            }
            case "vcard": {
                // Parse: "Full Name, Email, Phone, Company"
                const parts = inputValue.split(",").map((p) => p.trim());
                const name = parts[0] || "";
                const email = parts[1] || "";
                const phone = parts[2] || "";
                const org = parts[3] || "";
                return `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nEMAIL:${email}\nTEL:${phone}\nORG:${org}\nEND:VCARD`;
            }
            case "text":
            default:
                return inputValue;
        }
    }, [selectedType, inputValue]);

    const hasContent = inputValue.trim().length > 0 && inputValue !== "https://";

    const handleGenerate = () => {
        if (!hasContent) return;
        setIsGenerated(true);
        setSaveStatus("idle");
    };

    // Save QR code to the backend
    const handleSave = async () => {
        if (!qrName.trim()) {
            setSaveStatus("error");
            setStatusMessage("Please enter a name for your QR code");
            setTimeout(() => setSaveStatus("idle"), 3000);
            return;
        }

        setIsSaving(true);
        setSaveStatus("idle");
        try {
            await qrCodeAPI.create({
                name: qrName,
                type: selectedType,
                value: inputValue,
                color: qrColor,
                bgColor: bgColor,
                cornerStyle: cornerStyle,
            });
            setSaveStatus("success");
            setStatusMessage("QR code saved to your account!");
            setTimeout(() => setSaveStatus("idle"), 4000);
        } catch (err: unknown) {
            setSaveStatus("error");
            const message = err instanceof Error ? err.message : "Failed to save QR code";
            setStatusMessage(message);
            setTimeout(() => setSaveStatus("idle"), 4000);
        } finally {
            setIsSaving(false);
        }
    };

    // Download QR as PNG
    const handleDownloadPNG = () => {
        if (!qrRef.current) return;
        const svg = qrRef.current.querySelector("svg");
        if (!svg) return;

        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        const size = 1024;
        canvas.width = size;
        canvas.height = size;

        const svgData = new XMLSerializer().serializeToString(svg);
        const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(svgBlob);

        const img = new Image();
        img.onload = () => {
            ctx.fillStyle = bgColor;
            ctx.fillRect(0, 0, size, size);
            ctx.drawImage(img, 0, 0, size, size);
            URL.revokeObjectURL(url);

            const link = document.createElement("a");
            link.download = `${qrName || "qrcode"}.png`;
            link.href = canvas.toDataURL("image/png");
            link.click();
        };
        img.src = url;
    };

    // Download QR as SVG
    const handleDownloadSVG = () => {
        if (!qrRef.current) return;
        const svg = qrRef.current.querySelector("svg");
        if (!svg) return;

        const svgData = new XMLSerializer().serializeToString(svg);
        const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.download = `${qrName || "qrcode"}.svg`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
    };

    const handleReset = () => {
        setInputValue(selectedType === "url" ? "https://" : "");
        setQrColor("#7c3aed");
        setBgColor("#ffffff");
        setQrName("");
        setCornerStyle("rounded");
        setIsGenerated(false);
        setSaveStatus("idle");
    };

    return (
        <div className="p-6 lg:p-8 max-w-7xl">
            {/* Header */}
            <div className="mb-8">
                <h1 className="text-2xl font-bold tracking-tight">Create QR Code</h1>
                <p className="text-sm text-muted-foreground mt-1">
                    Choose a type, enter your content, and customize the design.
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                {/* ═══════ Left Panel: Configuration ═══════ */}
                <div className="lg:col-span-3 space-y-6">
                    {/* Step 1: Select Type */}
                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                        <div className="flex items-center gap-2 mb-5">
                            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 dark:bg-violet-500/10 text-xs font-bold text-violet-600 dark:text-violet-400">
                                1
                            </span>
                            <h2 className="text-base font-semibold">Select QR Type</h2>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {QR_TYPES.map((type) => (
                                <button
                                    key={type.value}
                                    onClick={() => {
                                        setSelectedType(type.value);
                                        setInputValue(type.value === "url" ? "https://" : "");
                                        setIsGenerated(false);
                                    }}
                                    className={cn(
                                        "flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all duration-200",
                                        selectedType === type.value
                                            ? "border-violet-500 bg-violet-50 dark:bg-violet-500/10 shadow-sm"
                                            : "border-border/50 hover:border-border hover:bg-muted/30"
                                    )}
                                >
                                    <div
                                        className={cn(
                                            "h-10 w-10 rounded-lg flex items-center justify-center flex-shrink-0",
                                            selectedType === type.value
                                                ? "bg-violet-100 dark:bg-violet-500/20 text-violet-600 dark:text-violet-400"
                                                : "bg-muted text-muted-foreground"
                                        )}
                                    >
                                        {iconMap[type.icon]}
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-sm font-semibold truncate">{type.label}</p>
                                        <p className="text-[11px] text-muted-foreground truncate">{type.description}</p>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Step 2: Enter Content */}
                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                        <div className="flex items-center gap-2 mb-5">
                            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 dark:bg-violet-500/10 text-xs font-bold text-violet-600 dark:text-violet-400">
                                2
                            </span>
                            <h2 className="text-base font-semibold">Enter Content</h2>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-2">QR Code Name</label>
                                <input
                                    type="text"
                                    value={qrName}
                                    onChange={(e) => setQrName(e.target.value)}
                                    placeholder="e.g., Company Website"
                                    className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">
                                    {selectedType === "url" ? "URL" :
                                        selectedType === "text" ? "Text Message" :
                                            selectedType === "vcard" ? "Contact Details" :
                                                selectedType === "wifi" ? "Wi-Fi Details" :
                                                    selectedType === "email" ? "Email Address" : "Phone Number"}
                                </label>
                                {selectedType === "text" || selectedType === "vcard" ? (
                                    <textarea
                                        value={inputValue}
                                        onChange={(e) => {
                                            setInputValue(e.target.value);
                                            setIsGenerated(false);
                                        }}
                                        placeholder={getPlaceholder()}
                                        rows={4}
                                        className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200 resize-none"
                                    />
                                ) : (
                                    <input
                                        type="text"
                                        value={inputValue}
                                        onChange={(e) => {
                                            setInputValue(e.target.value);
                                            setIsGenerated(false);
                                        }}
                                        placeholder={getPlaceholder()}
                                        className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all duration-200"
                                    />
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Step 3: Customize */}
                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
                        <div className="flex items-center gap-2 mb-5">
                            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 dark:bg-violet-500/10 text-xs font-bold text-violet-600 dark:text-violet-400">
                                3
                            </span>
                            <h2 className="text-base font-semibold">Customize Design</h2>
                        </div>

                        <div className="space-y-5">
                            {/* Colors */}
                            <div>
                                <label className="block text-sm font-medium mb-3 flex items-center gap-2">
                                    <Palette className="h-4 w-4 text-muted-foreground" />
                                    QR Code Color
                                </label>
                                <div className="flex items-center gap-2 flex-wrap">
                                    {presetColors.map((color) => (
                                        <button
                                            key={color}
                                            onClick={() => setQrColor(color)}
                                            className={cn(
                                                "h-9 w-9 rounded-xl border-2 transition-all duration-200 hover:scale-110",
                                                qrColor === color ? "border-foreground scale-110 shadow-md" : "border-transparent"
                                            )}
                                            style={{ backgroundColor: color }}
                                        />
                                    ))}
                                    <div className="relative">
                                        <input
                                            type="color"
                                            value={qrColor}
                                            onChange={(e) => setQrColor(e.target.value)}
                                            className="h-9 w-9 rounded-xl cursor-pointer border border-border opacity-0 absolute inset-0"
                                        />
                                        <div className="h-9 w-9 rounded-xl border border-dashed border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-foreground transition-colors">
                                            <span className="text-lg">+</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Background Color */}
                            <div>
                                <label className="block text-sm font-medium mb-3">Background Color</label>
                                <div className="flex items-center gap-3">
                                    <input
                                        type="color"
                                        value={bgColor}
                                        onChange={(e) => setBgColor(e.target.value)}
                                        className="h-9 w-12 rounded-lg cursor-pointer border border-border"
                                    />
                                    <input
                                        type="text"
                                        value={bgColor}
                                        onChange={(e) => setBgColor(e.target.value)}
                                        className="h-9 w-28 rounded-lg border border-input bg-background px-3 text-sm font-mono uppercase"
                                    />
                                </div>
                            </div>

                            {/* Corner Style */}
                            <div>
                                <label className="block text-sm font-medium mb-3">Corner Style</label>
                                <div className="flex gap-3">
                                    <button
                                        onClick={() => setCornerStyle("square")}
                                        className={cn(
                                            "flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all duration-200",
                                            cornerStyle === "square"
                                                ? "border-violet-500 bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-400"
                                                : "border-border hover:bg-muted/30"
                                        )}
                                    >
                                        <Square className="h-4 w-4" />
                                        Square
                                    </button>
                                    <button
                                        onClick={() => setCornerStyle("rounded")}
                                        className={cn(
                                            "flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all duration-200",
                                            cornerStyle === "rounded"
                                                ? "border-violet-500 bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-400"
                                                : "border-border hover:bg-muted/30"
                                        )}
                                    >
                                        <Circle className="h-4 w-4" />
                                        Rounded
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* ═══════ Right Panel: Preview & Download ═══════ */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm sticky top-24">
                        <h2 className="text-base font-semibold mb-5">Preview</h2>

                        {/* QR Preview Box */}
                        <div
                            className="rounded-2xl p-8 flex items-center justify-center mb-6 border border-border/30 min-h-[280px]"
                            style={{ backgroundColor: bgColor }}
                        >
                            <div ref={qrRef}>
                                {isGenerated && hasContent ? (
                                    <QRCodeSVG
                                        value={getQRValue()}
                                        size={200}
                                        fgColor={qrColor}
                                        bgColor={bgColor}
                                        level="H"
                                        marginSize={1}
                                    />
                                ) : (
                                    <div className="w-48 h-48 flex flex-col items-center justify-center text-muted-foreground/40">
                                        <svg viewBox="0 0 200 200" className="w-32 h-32 opacity-30">
                                            {/* Placeholder QR pattern */}
                                            <rect x="10" y="10" width="50" height="50" rx="8" fill={qrColor} opacity={0.3} />
                                            <rect x="17" y="17" width="36" height="36" rx="5" fill={bgColor} />
                                            <rect x="24" y="24" width="22" height="22" rx="3" fill={qrColor} opacity={0.3} />
                                            <rect x="140" y="10" width="50" height="50" rx="8" fill={qrColor} opacity={0.3} />
                                            <rect x="147" y="17" width="36" height="36" rx="5" fill={bgColor} />
                                            <rect x="154" y="24" width="22" height="22" rx="3" fill={qrColor} opacity={0.3} />
                                            <rect x="10" y="140" width="50" height="50" rx="8" fill={qrColor} opacity={0.3} />
                                            <rect x="17" y="147" width="36" height="36" rx="5" fill={bgColor} />
                                            <rect x="24" y="154" width="22" height="22" rx="3" fill={qrColor} opacity={0.3} />
                                        </svg>
                                        <p className="text-sm mt-3 font-medium">Enter content & click Generate</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Info */}
                        <div className="space-y-2 mb-6">
                            <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Type</span>
                                <span className="font-medium capitalize">{selectedType}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Color</span>
                                <div className="flex items-center gap-2">
                                    <div className="h-4 w-4 rounded-md border border-border" style={{ backgroundColor: qrColor }} />
                                    <span className="font-mono text-xs uppercase">{qrColor}</span>
                                </div>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Corners</span>
                                <span className="font-medium capitalize">{cornerStyle}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Status</span>
                                <span className={cn(
                                    "font-medium",
                                    isGenerated ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"
                                )}>
                                    {isGenerated ? "✓ Generated" : "Pending"}
                                </span>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="space-y-3">
                            {/* Generate Button */}
                            <button
                                onClick={handleGenerate}
                                disabled={!hasContent || isGenerating}
                                className="w-full h-11 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-sm font-semibold text-white shadow-md shadow-violet-500/20 transition-all duration-200 hover:shadow-lg hover:shadow-violet-500/30 hover:scale-[1.01] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
                            >
                                {isGenerating ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                    <Sparkles className="h-4 w-4" />
                                )}
                                Generate QR Code
                            </button>

                            {/* Save to Account Button */}
                            {isGenerated && (
                                <button
                                    onClick={handleSave}
                                    disabled={isSaving}
                                    className="w-full h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-sm font-semibold text-white shadow-sm transition-all duration-200 hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                                >
                                    {isSaving ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                        <Save className="h-4 w-4" />
                                    )}
                                    Save to Account
                                </button>
                            )}

                            {/* Download Buttons */}
                            {isGenerated && (
                                <div className="grid grid-cols-2 gap-3">
                                    <button
                                        onClick={handleDownloadPNG}
                                        className="h-10 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
                                    >
                                        <Download className="h-4 w-4" />
                                        PNG
                                    </button>
                                    <button
                                        onClick={handleDownloadSVG}
                                        className="h-10 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
                                    >
                                        <Download className="h-4 w-4" />
                                        SVG
                                    </button>
                                </div>
                            )}

                            <button
                                onClick={handleReset}
                                className="w-full h-10 rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors flex items-center justify-center gap-2"
                            >
                                <RotateCcw className="h-4 w-4" />
                                Reset
                            </button>
                        </div>

                        {/* Status Messages */}
                        {saveStatus === "success" && (
                            <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-sm font-medium flex items-center gap-2 animate-fade-in-up">
                                <CheckCircle2 className="h-4 w-4 flex-shrink-0" />
                                {statusMessage}
                            </div>
                        )}
                        {saveStatus === "error" && (
                            <div className="mt-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm font-medium flex items-center gap-2 animate-fade-in-up">
                                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                                {statusMessage}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
